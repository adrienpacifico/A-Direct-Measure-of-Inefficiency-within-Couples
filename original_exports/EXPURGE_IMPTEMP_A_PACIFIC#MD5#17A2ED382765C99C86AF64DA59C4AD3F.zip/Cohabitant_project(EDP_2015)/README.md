To execute the project :  

1. Open Jupyter preferably with Winpython 2.7.10.2 (portable version) 
To do so, type 
` ipython notebook --no-mathjax`  (or `jupyter notebook --no-mathjax` if you are using a more recent version of Winpython.  

2. open the 1-Start.ipynb file and read the instructions in the file which can be summarized by :  
     1. Run the Sas script to export the Sas files to csv (you need to change the path to the directory where the sas7bdat files are.  
     2. Execute the notebook